<?php
    class queries extends CI_Model{

        public function post()
        {
            $query = $this->db->get('wholesaler');
            if($query->num_rows() > 0){
                return $query->result();
            }
        }

        public function addPost($data)
        {
            return $this->db->insert('wholesaler', $data);
        }

        public function getSingle($id)
        {
            $query = $this->db->get_where('wholesaler', array('id' => $id));
            if($query->num_rows() > 0){
                return $query->row();
            }
        }

        public function updatePost($data, $id)
        {
            // return $this->db->update('wholesaler',['id'=>$id]);
            return $this->db->where('id',$id)
                        ->update('wholesaler',$data);
            
             
         }
        public function deletePost($id)
        {
            return $this->db->delete('wholesaler',['id'=>$id]);
        }
       
    }

?>