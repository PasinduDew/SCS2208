<?php include_once('header.php'); ?>
    <div class="container">
    

        <?php echo form_open("welcome/change/{$post->id}", ['class'=>'form-horizontal']);?>
            <fieldset>
            <br></br>
                <legend>Update Wholesaler</legend>
                <!-- <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" readonly="" class="form-control-plaintext" id="staticEmail" value="email@example.com">
                </div>
                </div> -->


                <div class="form-group">
                <label for="inputEmail"  class="col-md-2 control-label">Name</label>
                <!-- <input type="text" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Wholesaler name"> -->
                <?php echo form_input(['name'=>'Name','placeholder'=>'Name','class'=>'form-control', 'value'=>set_value('Name',$post->Name)]);?>
                    <div>
                        <?php echo form_error('Name','<div class="text-danger">','</div>');?>
                    </div>
                </div>
            
                <div class="form-group">
                <label for="textArea" class="col-md-2 control-label">Institute</label>
                <!-- <input type="text" class="form-control" id="textArea" placeholder="Name of the Institute"> -->
                <?php echo form_textarea(['name'=>'Institute','placeholder'=>'Institute','class'=>'form-control','value'=>set_value('Institute',$post->Institute)]);?>
                    <div>
                        <?php echo form_error('Institute','<div class="text-danger">','</div>');?>
                    </div>
                </div>

                <div class="form-group">
                <label for="textArea"  class="col-md-2 control-label">Address</label>
                <!-- <input type="text" class="form-control" id="textArea" placeholder="Address of the Institute"> -->
                <?php echo form_textarea(['name'=>'Address','placeholder'=>'Address','class'=>'form-control','value'=>set_value('Address',$post->Address)]);?>
                    <div>
                        <?php echo form_error('Address','<div class="text-danger">','</div>');?>
                    </div>
                </div>

                <div class="form-group">
                <label for="inputEmail"  class="col-md-2 control-label">Email</label>
                <!-- <input type="text" class="form-control" id="inputEmail" placeholder="example@example.com"> -->
                <?php echo form_input(['name'=>'Email','placeholder'=>'Email','class'=>'form-control','value'=>set_value('Email',$post->Email)]);?>
                    <div>
                        <?php echo form_error('Email','<div class="text-danger">','</div>');?>
                    </div>
                </div>

                <div class="form-group">
                <label for="inputEmail"  class="col-md-2 control-label">Telephone</label>
                <!-- <input type="text" class="form-control" id="inputEmail" placeholder="**********"> -->
                <?php echo form_input(['name'=>'Telephone','placeholder'=>'Telephone','class'=>'form-control','value'=>set_value('Telephone',$post->Telephone)]);?>
                    <div>
                        <?php echo form_error('Telephone','<div class="text-danger">','</div>');?>
                    </div>
                </div>

                <div class="form-group">
                    <div class = "col-md-10 col-md-offset-2">
                    <!-- <button type="reset" class="btn btn-primary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit</button> -->
                    <?php echo form_submit(['name'=>'submit', 'value'=>'Update', 'class'=>'btn btn-primary']);?>
                    <?php echo anchor('welcome', 'Back', ['class'=>'btn btn-primary']);?>            
                    </div>
                </div>
                
            <fieldset>   
        <?php echo form_close();?>

    </div>


<?php include_once('footer.php'); ?>