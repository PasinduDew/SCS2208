<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
    <div class="navbar-header">

    <a class="navbar-brand" href="#"></a>
    </div>
    </div>
</nav>