<?php include_once('header.php'); ?>
    <div class="container">
<h3>View Wholesaler</h3>
    <h4><?php echo $post->Name;?></h4>
    <h4><?php echo $post->Institute;?></h4>
    <h4><?php echo $post->Address;?></h4>
    <h4><?php echo $post->Email;?></h4>
    <h4><?php echo $post->Telephone;?></h4>
    <?php echo anchor('welcome', 'Back', ['class'=>'btn btn-primary']);?>       
    <br></br>
    </div>
    <?php include_once('footer.php'); ?>
