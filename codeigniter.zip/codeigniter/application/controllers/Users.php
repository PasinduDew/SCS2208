<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Users_model');
	}

	public function index(){
		$data['products'] = $this->Users_model->getAllUsers();
		$this->load->view('user_list.php', $data);
	}

	public function addnew(){
		$this->load->view('addform.php');
	}

	public function insert(){
		$user['Product_name'] = $this->input->post('Product_name');
		$user['Product_code'] = $this->input->post('Product_code');
		$user['Price'] = $this->input->post('Price');
		$user['Quantity'] = $this->input->post('Quantity');
		$user['Description'] = $this->input->post('Description');
		
		$query = $this->Users_model->insertuser($user);

		if($query){
			header('location:'.base_url().$this->index());
		}

	}

	public function edit($id){
		$data['user'] = $this->Users_model->getUser($id);
		$this->load->view('editform', $data);
	}

	public function update($id){
		$user['Product_name'] = $this->input->post('Product_name');
		$user['Product_code'] = $this->input->post('Product_code');
		$user['Price'] = $this->input->post('Price');
		$user['Quantity'] = $this->input->post('Quantity');
		$user['Description'] = $this->input->post('Description');

		$query = $this->Users_model->updateuser($user, $id);

		if($query){
			header('location:'.base_url().$this->index());
		}
	}

	public function delete($id){
		$query = $this->Users_model->deleteuser($id);

		if($query){
			header('location:'.base_url().$this->index());
		}
	}
}


?>