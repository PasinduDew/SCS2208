<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter Simple CRUD Tutorial</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">Products</h1>
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<h3>Edit Form
				<span class="pull-right"><a href="<?php echo base_url(); ?>" class="btn btn-primary"> Back</a></span>
			</h3>
			<hr>
			<?php extract($user); ?>
			<form method="POST" action="<?php echo base_url(); ?>index.php/users/update/<?php echo $id; ?>">
				<div class="form-group">
					<label>Product_name:</label>
					<input type="text" class="form-control" value="<?php echo $Product_name; ?>" name="Product_name">
				</div>
				<div class="form-group">
					<label>Product_code:</label>
					<input type="text" class="form-control" value="<?php echo $Product_code; ?>" name="Product_code">
				</div>
				<div class="form-group">
					<label>Price:</label>
					<input type="text" class="form-control" value="<?php echo $Price; ?>" name="Price">
				</div>
				<div class="form-group">
					<label>Quantity:</label>
					<input type="text" class="form-control" value="<?php echo $Quantity; ?>" name="Quantity">
				</div>
				<div class="form-group">
					<label>Description:</label>
					<input type="text" class="form-control" value="<?php echo $Description; ?>" name="Description">
				</div>
				<button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-check"></span> Update</button>
			</form>
		</div>
	</div>
</div>
</body>
</html>