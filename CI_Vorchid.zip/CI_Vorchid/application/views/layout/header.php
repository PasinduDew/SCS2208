<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css" >

    <title>Registration Page</title>
  </head>
  <body>
  	<br><br>
  	<div class="container-fluid header" >
  		<div class="navbar navbar-default container" >
  			<h1>Welcome to VORCHID</h1>
  		</div>
  	</div>