<html lang="en">
<head>
	<meta charset="utf-8">
	<title>View Wholesaler</title>
	<script type ="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js'  );?>"></script>
	<script type ="text/javascript" src="<?php echo base_url('assets/js/jquery-3.4.1.min.js');?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
</head>
</html>



<?php include_once('Dashboard_Header.php'); ?>
    <div class="container">
<h3>View Wholesaler</h3>
    <h4><?php echo $post->Name;?></h4>
    <h4><?php echo $post->Institute;?></h4>
    <h4><?php echo $post->Address;?></h4>
    <h4><?php echo $post->Email;?></h4>
    <h4><?php echo $post->Telephone;?></h4>
    <?php echo anchor('welcome', 'Back', ['class'=>'btn btn-primary']);?>       
    <br></br>
    </div>
    <?php include_once('Dashboard_Footer.php'); ?>
