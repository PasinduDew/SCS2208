<section class="section section-light">
        <h2>Our Vision</h2>
        <p>
            This paragraph explains our vision !
        </p>
    </section>

    <div class="pimg2">
        <div class="ptext">
            <!-- <span class="border">
                Image Two Text
            </span> -->
        </div>
    </div>

    <section class="section section-light">
            <h2>Our Mission</h2>
            <p>
               This paragraph explains our Mission !
            </p>
        </section>

    <div class="pimg3">
        <div class="ptext">
            <!-- <span class="border">
                    Image Three Text
            </span> -->
        </div>
    </div>

    <section class="section section-light">
		<h2>About Us</h2>
		<p>
			This paragraph explains our details !
		</p>
</section>

    
